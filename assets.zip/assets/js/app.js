// Paths

var system_paths = {

	net: {

		assets:		'Assets/cars/',
		results:	'results?',
		api:		'api/car',

	},

	php: {

		assets:		'assets/cars/',
		results:	'results.php?',
		api:		'api/car.json',

	}

};

var carColors = {
					
	'Volcanic Orange':		'#f7941d',
	'Electric Blue':		'#30b6e8',
	'Lightning Blue':		'#1164ac',
	'Jungle Green':			'#426046',
	
	'Chili red':			'#d71d24',
	'Blazing Red':			'#d71d24',
	
	'Pepper white':			'#e4dfce',
	'Light white':			'#e4dfce',

}

// Setup namespace and some global variables

var $html	= $( 'html' );
var	$body	= $( 'body' );
var	w		= window;

var Mini	= {

	settings: {

		debug:			true,

	},

	thirdParty: {

		facebookID:		892580704115737,
		analyticsID:	'UA-000000-01'

	},

	browser: {

		name:			$.browser.name,
		version:		$.browser.version,
		mobile: 		$.browser.mobile || false,
		platform:		$.browser.platform,

		// Quick fuction to check IE version

		isIE:			function( version ) {

			switch( typeof( version ) ) {

				case 'string': return ( $.browser.name === 'msie' && $.browser.platform === 'win' && eval( parseInt( $.browser.version ) + version ) ); break;
				
				case 'number': return ( $.browser.name === 'msie' && $.browser.platform === 'win' && parseInt( $.browser.version ) === version ); break;

				default: return ( $.browser.name === 'msie' && $.browser.platform === 'win' ); break;

			}

		}

	}

};

// Add some useful classes to the <html> element

document.querySelector( 'html' ).className += ' ' + Mini.browser.platform;

// Add browser name via JavaScript if it's not IE

if( ! Mini.browser.isIE() ) document.querySelector( 'html' ).className += ' ' + Mini.browser.name;

// We have to manually append .js class to the <html> element if modernizr isn't used

if( typeof( Modernizr ) === 'undefined' ) {

	var bodyClass = document.querySelector( 'html' ).className;

	document.querySelector( 'html' ).className = bodyClass.replace( 'no-js', 'js' );

}

// Plugins

jQuery.fn.removeClassExcept = function ( val ) {

	return this.each( function( index, el ) {
		
		var keep = val.split( ' ' );
		var reAdd = [];
		var $el = $(el);
	
		for( var c = 0; c < keep.length; c++ ) {

			if( $el.hasClass( keep[ c ] ) ) reAdd.push( keep[ c ] );

		}

	
	$el.removeClass().addClass( reAdd.join( ' ' ) );
	
	} );

};


var o = $({});

$.subscribe = function() {
	o.on.apply(o, arguments);
};

$.unsubscribe = function() {
	o.off.apply(o, arguments);
};

$.publish = function() {
	o.trigger.apply(o, arguments);
};
( function( Mini ) {

	$.validator.setDefaults( {

		// Setup form validation rules here

		rules: {

			'name': { required: true },
			'surname': { required: true },
			'address-1': { required: true },
			'address-2': { required: true },
			'address-3': { required: true },
			'address-4': { required: true },
			'home': { required: true },
			'work': { required: true },
			'mobile': { required: true },
			'dealer': { required: true },
			'title': { required: true },
			'postcode': { required: true },
			'email': {

				required: true,
				email: true

			},

		},

		// And new messages here
		
		messages: {

			'name': { required:			'First name is required.' },
			'surname': { required:		'Last name is required.' },
			'address-1': { required:	'Address line 1 is required.' },
			'address-2': { required:	'Address line 2 is required.' },
			'address-3': { required:	'Address line 3 is required.' },
			'address-4': { required:	'Address line 4 is required.' },
			'home': { required:			'Home telephone is required.' },
			'work': { required:			'Work telephone is required.' },
			'mobile': { required:		'Mobile telephone is required.' },
			'dealer': { required:		'Please choose a dealer from the list.' },
			'title': { required:		'Title is required.' },
			'postcode': { required:		'Postcode is required.' },
			'email': {

				required: 'E-mail is required.',
				email: 'Please enter a valid e-mail address.'

			}

		}
		
	} );

} )( Mini );
( function( Mini ) {

	$.validator.setDefaults( {

		showErrors: function( errors, elements ) {

			if( elements.length > 0 ) {

				$( elements ).each( function( i, el ) {

					// Add the .error class to the element

					var el = el.element,
						elementType = el.tagName.toLowerCase();					

					if( elementType === 'select' ) {

						$( el ).parent().addClass( 'error' );

					}
					
					else {

						$( el ).addClass( 'error' );

					}

					// Validate the fields here

				} );

				if( Mini.settings.debug ) {

					console.warn( 'The following form inputs have errors:' );

					$( elements ).each( function( i, el ) {

						if( ! $( el.element ).closest( '.form-control' ).find( '.form-error' )[ 0 ] ) $( el.element ).closest( '.form-control' ).append( '<span class="form-error">' + el.message + '</span>' );

					} );

				}

			}

		},

		submitHandler: function( form ) {

			var ajaxURL = $( form ).attr( 'action' ),
				ajaxDelay = 1000; // Not needed but included here to illustrate the loading DIV behaviour

			var ajaxRequest = function() {

				$.ajax( {

					type: 'POST',
					async: false,
					url: ajaxURL,
					data: $( form ).serialize(),
					dataType: 'json',
					complete: function() {

						$( form ).toggleClass( 'busy' );

					},
					success: function( data ) {

						if( Mini.settings.debug ) {

							console.log( 'Successfully submitted form to: ' + ajaxURL );
							console.log( data );

						}

						// Process data here

						// This is for mobile, so the form stays in view

						$( 'html, body' ).animate( {

							scrollTop: $( form ).offset().top

						}, 200 );

					},
					error: function( xhr ) {

						if( Mini.settings.debug ) {

							console.log( 'Couldn\'t submit the form with AJAX, returning XHR object:' );
							console.log( xhr );

						}

					},
					beforeSend: function() { if( Mini.settings.debug ) console.log( 'Submitting form to: ' + ajaxURL ); } // Feel free to remove this if not needed

				} );	

			};

			// Disable the form to prevent accidental submission while the request is pending

			$( form ).toggleClass( 'busy' );

			// Perform the call

			setTimeout( function() { ajaxRequest(); }, ajaxDelay );			

		},

		ignore: false,

		onkeyup: function( el ) {

			$( el ).removeClass( 'error' );
			$( el ).parent().removeClass( 'error' );
			$( el ).closest( '.form-control' ).find( '.form-error' ).remove();

		},
		onfocusout: function( el ) {

			$( el ).removeClass( 'error' );
			$( el ).parent().removeClass( 'error' );
			$( el ).closest( '.form-control' ).find( '.form-error' ).remove();

		}

	} );

} )( Mini );
( function( Mini ) {
	
	$body.on( 'click', '.js-sharer li a', function( e ) {

		e.preventDefault();

		var $link		= $( this );
		var website		= $( this ).parent();
		var title		= website.attr( 'title' );
		var currentURL	= location.href;

		switch( $( website ).attr( 'class') ) {

			case 'facebook':

				FB.ui( {
					
					method: 'share',
					href: currentURL,

				},

				function( response ) {

					console.log( response );

				} );

			break;

			case 'twitter':

				var hashtags = website.data( 'hashtags' );

				if( hashtags === undefined ) hashtags = '';

				window.open( 'https://twitter.com/intent/tweet?url=' + currentURL + '&hashtags=' + hashtags, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600' );

			break;

			case 'gplus':

				window.open( 'http://plus.google.com/share?url=' + currentURL, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600' );

			break;

			case 'print': window.print(); break;
			
			case 'mail':

				dialog( 'Please enter your friend\'s e-mail address.', 'prompt', function() {

					var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				
					if( regex.test( this ) ) {

						window.location.href = 'mailto:' + this + '?subject=Check this out&body=Hello there, I thought you\'ll find it interesting: ' + currentURL;

					}
					else{

						dialog( 'The e-mail address seems invalid. Please try again.' );

					}

				} );

			break;

		}

	} );

} )( Mini );
var Mini = Mini || {};

"use strict";

var path = ( location.href.indexOf( 'localhost' ) >= 0 ) ? system_paths.net : system_paths.php;

// indexof polyfill for <ie9
if (!Array.prototype.indexOf) {
  Array.prototype.indexOf = function(elt /*, from*/) {
	var len = this.length >>> 0;

	var from = Number(arguments[1]) || 0;
	from = (from < 0)
		 ? Math.ceil(from)
		 : Math.floor(from);
	if (from < 0)
	  from += len;

	for (; from < len; from++) {
	  if (from in this &&
		  this[from] === elt)
		return from;
	}
	return -1;
  };
}

Mini.DOMCtrl = {

	_apiData: null,
	_$page: $(document),

	init: function () {
		var self = this;
		this.pubsub();

		// show the default panel
		this.panelControl('default');

		this.registerDataEvents();
		this.getData();

		// dev options
		//$.ajaxSetup({ cache:false });

	},

	// Set up listeners for async functions
	registerDataEvents: function(){
		var self = this;

		$.subscribe('data-ready', function(e, response){

			self._apiData = response;

			$.subscribe('combobulate-raw', function(e, response){
				console.log(response);
				var query = self.combobulateToQuery(response);
				Mini.UILogic._query = query;
				console.log(query);

				// trigger the search
				Mini.UILogic.carCollectionController(self._apiData);

			});

		});

	},

	panelControl: function(panel){
		this._$page.find('[data-panel-name]').removeClass( 'panel-active' );
		this._$page.find('[data-panel-name="' + panel + '"]').addClass( 'panel-active' );
	},

	// Contact the API and collect the data
	// Publish the results
	getData: function(){
		$.getJSON(Mini.UILogic._jsonUrl, function(response) {
			var obj = {};
			obj.Models = response;
			$.publish('data-ready', obj);
		}).error(function(jqXHR, textStatus, errorThrown){
			console.log(jqXHR.responseText);
			console.log("failed");
		});
	},

	// Convert the raw combobulator data to search query format 
	combobulateToQuery: function(data){

		function mpg(mpg){
			var scale;
			if (mpg < 46) { scale = 1 } else
			if (mpg < 61) { scale = 2 } else
			if (mpg < 70) { scale = 3 } else
			if (mpg > 69) { scale = 4 } else {
				scale = 0;
			}
			return scale;
		};

		function price(pounds){
			console.log(pounds)
			var scale;
			if (pounds == 0) { scale = 0 } else
			if (pounds < 191) { scale = 6 } else
			if (pounds < 216) { scale = 1 } else
			if (pounds < 246) { scale = 2 } else
			if (pounds < 270) { scale = 3 } else
			if (pounds < 295) { scale = 4 } else
			if (pounds > 295) { scale = 5 } else {
				scale = 0;
			}
			return scale;
		};

		function luggage(string){
			var options = {
				"minimalist" : 1,
				"light-packer": 2,
				"lugger" : 3,
				"big-loader" : 4
			}
			var output = options[string];
			if (typeof output === 'undefined') {
				output = 0;
			}
			return output;
		};

		function lifestyle(string){
			var options = {
				"urbanite" : 1,
				"beach-bum": 2,
				"mountain-ranger" : 3,
				"junglist" : 4
			}
			var output = options[string];
			if (typeof output === 'undefined') {
				output = 0;
			}
			return output;
		};

		// Build the easter egg array
		function easterEggs(arr1, arr2){

			// Possible values
			// ["Dog","Alien","Cat","teleportation"];

			var o = {};

			// Set the value of teleportation
			o.teleportation = arr2.indexOf("4") != -1;

			for (var i = 0; i < arr1.length; i++) {
				var string = arr1[i];
				if (typeof string === 'string' && string === 'Dog' || string === 'Alien' || string === 'Cat'){
					o[string] = 1;
				}
			}
			return o;
		}

		// Remove teleportation from the options array
		function carOptions(arr){
			function pin() {
				arr.pop()
				return arr;
			}
			return (arr.indexOf("4") != -1) ? pin() : arr;
		}

		function capacity(arr){

			// Possible values
			//["Woman", "Man", "Girl", "Boy", "Infant", "Dog","alien", "cat"]

			var o = {}
			o.people = 0;
			o.children = 0;
			o.infant = 0;
			var output;

			function seatArrayToObject(arr) {

				for (var i = 0; i < arr.length; i++) {
					var string = arr[i];
					//console.log(string);

					if (typeof string === 'string' && string == 'Man' || string == 'Woman'){
						o.people++;
					} else if (typeof string === 'string' && string == 'Girl' || string == 'Boy'){
						o.children++;
					} else if (typeof string === 'string' && string === 'Infant'){
						o.infant++;
					}

				};

				return o;

			};

			function peopleObjectToScale(o){

				o.family = o.people + o.children;

				//console.log(o);

				if (o.family <= 2 && o.infant === 0) {
					//console.log('o.family <= 2 && o.infant === 0')
					return 1;
				}

				if (o.people === 2 && (0 < o.children && o.children <= 2) && o.infant === 0) {
					//console.log('o.people === 2 && (0 < o.children && o.children <= 2) && o.infant === 0')
					return 3;
				}
				if (o.people === 1 && (0 < o.children && o.children <= 3) && o.infant === 0) {
					//console.log('o.people === 1 && (0 < o.children && o.children <= 3) && o.infant === 0')
					return 3;
				}

				if (o.family <= 4 && o.infant === 0){
					//console.log('o.family <= 4 && o.infant === 0')
					return 2;
				}
				if (o.family <= 3 && o.infant === 1){
					//console.log('o.family <= 3 && o.infant === 1')
					return 2;
				}

				if (o.family === 5) {
					//console.log('o.family === 5')
					return 4;
				}

				if (o.family === 4 && o.infant === 1) {
					//console.log('o.family === 4 && o.infant === 1')
					return 4;
				}

				if (o.family === 3 && o.infant === 2) {
					//console.log('o.family === 3 && o.infant === 2')
					return 4;
				}

			}

			return peopleObjectToScale( seatArrayToObject(arr) );

		};

		var query = {};
		query.CapacityScale = capacity(data.seats);
		query.EconomyScale = mpg(data.mpg);
		query.Eggs = easterEggs(data.seats, data.options);
		query.LuggageScale = luggage(data.luggage);
		query.Options = carOptions( data.options );
		query.PerformanceScale = data.speed;
		query.PriceScale = price(data.price);
		query.UsageScale = lifestyle(data.lifestyle);
		return query;
	},

	// Accepts the filtered car collection
	// Randomises the collection
	// Renders to the view
	resultsViewCtrl: function(resultsCollection){
		var self = this;

		var Helpers = {

			shuffle: function(array) {
				var m = array.length, t, i;
				// While there remain elements to shuffle…
				while (m) {
					// Pick a remaining element…
					i = Math.floor(Math.random() * m--);
					// And swap it with the current element.
					t = array[m];
					array[m] = array[i];
					array[i] = t;
				}
				return array;
			},

			isValueLegitimate: function(value){
				return value !== 'n/a' && typeof value !== 'undefined' && value !== null && value != 0;
			},

			determineColour: function(string){

				return (Helpers.isValueLegitimate(string)) ? carColors[string] : carColors[ 'Chili red' ];
			}

		};

		var Render = {

			finalCount: function(count){
				var panel = $('#tools');
				panel.find('h3').text('Debug tools - showing: ' + count);
			},

			carToView: function(car){

				var imageUrl = path.assets;
				var resultsUrl = path.results;
				var colour = Helpers.determineColour(car.Colour);
				var $customerId = self._$page.find('#uid').attr('value');
				var $panel = self._$page.find('.panel[data-panel-name=results]');

				function resultsPageUrl(cId, url, mCode){
					return (Helpers.isValueLegitimate(cId)) ? url + 'c=' + cId + '&m=' + mCode : url + 'm=' + mCode;
				}

				console.warn( $panel );

				$panel.find('[data-model-name]').html(car.Model);
				$panel.find('[data-model-code]').html(car.ModelCode);
				$panel.find('[data-model-price]').html(car.Cost);
				
				$panel.find('[data-model-image]').hide().attr( { src: imageUrl + car.ModelCode + '.jpg' } ).fadeIn( 200 );

				$panel.find('[data-terms]').html(car.TermsConditions);
				$panel.find('[data-results-link]').attr({href: resultsPageUrl($customerId, resultsUrl, car.ModelCode)});

				// Trigger the colour change function
				$.publish('colour-change', colour);

			}
		}

		// by default we store each search as a new array
		// latest is last array
		var resultToShow = resultsCollection.slice(-1).pop();

		// debug only - show the number of cars returned
		Render.finalCount(resultToShow.length);

		// More than one car we randomise
		if(resultToShow.length >=2) {
			// randomize the result
			resultToShow = Helpers.shuffle(resultToShow);
		}

		// show the results panel
		this.panelControl('results');

		Render.carToView(resultToShow[0]);

	},

	// jQuery Tiny Pub/Sub
	pubsub: function() {

		

	}

};

Mini.UILogic = {
	_query: null,
	_collection: null,
	_order: ['CapacityScale', 'LuggageScale', 'Options', 'PriceScale', 'PerformanceScale', 'EconomyScale', 'UsageScale' ],
	_jsonUrl: path.api,

	init: function(){
		this._collection = this.CarsFactory();
	},

	carCollectionController: function(response){
		var self = this;
		var cars = response;
		var settings = {
			minNoResults: 2,
			easterEggs : {
				'PerformanceScale' : 5,
				'PriceScale' : 6
			}
		}

		var counter = {
			count:0,
			update: function(){
				this.count++;
			},
			echo: function(){
				return this.count;
			}
		}

		var Helpers = {

			convertValueToArray: function(value){
				if(typeof value === 'number') {
					value = value.toString();
				}
				if(typeof value === 'string' && value.length > 1) {
					value = value.split('');
				}
				return value;
			},

			matchSingleValueInArrary: function(array, userProp){
				return array.indexOf(userProp) != -1;
			},

			matchArrayValuesInArrary: function(array, userArray){
				var len=userArray.length;
				var count=0;

				if (typeof userArray !== 'object') {return false;}

				// console.log('we got an array')
				// console.log(array);
				// console.log(userArray);

				// Match all userArray values to pass
				for (var i=0; i<len;i++) {
					if(!Helpers.matchSingleValueInArrary(array, userArray[i])) {
						return false;
					}
					count++;
					if (len===count){
						return true;
					}
				};
			},

			areValuesValid: function(dValue, qValue){
				return Helpers.isValueLegitimate(dValue) && Helpers.isValueLegitimate(qValue);
			},

			doValuesMatch: function(numberArray, qValue) {
				// attempt to match array values to target
				// else match single value to target
				return Helpers.matchArrayValuesInArrary(numberArray, qValue) || Helpers.matchSingleValueInArrary(numberArray, qValue)
			},

			isValueLegitimate: function(value){
				return value !== 'n/a' && value !== 'TBC' && typeof value !== 'undefined' && value !== null && value != 0;
			},

			shallWeContinueTheLoop: function(array, nextProperty){
				// console.log(array.length)
				// console.log(settings.minNoResults)
				// console.log(array.length > settings.minNoResults)
				// console.log(nextProperty)
				// console.log(typeof nextProperty !== 'undefined')
				// console.log(!!(array.length > settings.minNoResults && typeof nextProperty !== 'undefined'))
				return !!(array.length > settings.minNoResults && typeof nextProperty !== 'undefined');
			}
		}

		var Filter = {
			store : [],
			reduced : 0,

			outputDatasetMessages: function(queryProp, dataSet){
				console.log(this.reduced)
				if(this.reduced !== 0) {
					console.log('reduced by : ' + (dataSet.length - this.reduced));
				} else {
					console.log('not reduced')
				}
				console.log(Filter.store);
			},

			// accepts database value, query value, record
			// check: dataset & query value contains valid content
			// match: do any values in query match the values in the data
			matchDatasetValueAgainstQueryValue: function(dValue, qValue, obj){

				// convert the dataset value into an array
				var numberArray = Helpers.convertValueToArray(dValue);

				// ensure the query number is a string for matching
				qValue = qValue.toString();

				var matchAccept = function(){
					Filter.addObjectToCollection(obj);
					return true;
				}

				var matchReject = function(){
					//console.log('skipped value');
				}

				return !!Helpers.areValuesValid(dValue, qValue) && ( Helpers.doValuesMatch(numberArray, qValue) ? matchAccept() : matchReject() );
			},

			matchSingleRecord: function(object){
				var record = this;
				for (var prop in object) {
					if(Helpers.isValueLegitimate(object[prop]) && object[prop]==record[prop]){
						return true;
					}
				}
			},

			addObjectToCollection: function(obj){
				//console.log('added')
				Filter.store.push(obj);
				Filter.reduced++;
			},

			// requires array of objects, search order array
			// check: are the conditions right to break out of loop
			// recurse with next filter property or render final results
			haveWeReachedTheEnd: function(resultCollection, order) {

				var continueLoop = function(){
					counter.update();
					console.log('Dataset still large so next is > ' + order[counter.echo()]);
					filterObjectsWithProperty(resultCollection, order[counter.echo()]);
				}

				var endLoopThenRender = function(){
					// console.log('endLoopThenRender')
					// console.log('Finished: Rendering results!')
					self._collection.add(resultCollection);

					// Filering complete return result to view controller
					Mini.DOMCtrl.resultsViewCtrl( Mini.UILogic._collection.all() );
				}

				return Helpers.shallWeContinueTheLoop( resultCollection, order[(counter.echo()+1)]) ? continueLoop() : endLoopThenRender();
			},

			// requires dataset value attempt to match with queryValue
			// success adds this record to the collection 
			continueMasterLoop: function(record, prop){
				Filter.matchDatasetValueAgainstQueryValue(record[prop], self._query[prop], record);
			},

			endMasterLoop: function(dataSet, prop){
				console.log('end')

				// output console message
				Filter.outputDatasetMessages(prop, dataSet);

				if(this.reduced === 0) {
					Filter.store = dataSet;
				}

				// if endpoint not reached recurse
				// otherwise exit
				Filter.haveWeReachedTheEnd(Filter.store, self._order);
			},

			renderSingleRecordThenExit: function(record){
				//console.log('renderSingleRecordThenExit')
				//console.log('Finished: Rendering results');
				console.log(record);
				Filter.addObjectToCollection(record[0]);
				self._collection.add(Filter.store);

				// Filering complete return result to view controller
				Mini.DOMCtrl.resultsViewCtrl( Mini.UILogic._collection.all() );
			}
		}

		// accepts an array of objects & property string to match
		// match: success add parent object to collection
		// if break criteria is not met, call recursively
		function filterObjectsWithProperty(dataSet, prop){
			// reset values for this loop
			Filter.store = [];
			Filter.reduced = 0;

			console.log('This is ' + prop + ': ' + self._query[prop]);

			// Main loop through dataset
			for (var i=0; i<dataSet.length; i++) {
				var record = dataSet[i];

				Filter.continueMasterLoop(record, prop)

				// if last entry in set trigger end condition
				// else continue looping trough the data
				if(i===dataSet.length-1) { Filter.endMasterLoop(dataSet, prop) }

			};

			console.log('end of ' + prop);

		};

		// check: does query value match easter egg criteria
		function hasUserSelectedEasterEgg(query){
			// does the query prop/value match one in the basket
			for (var prop in query) {
				if(Helpers.isValueLegitimate(query[prop]) && query[prop]==settings.easterEggs[prop]){
					var obj = {}
					obj[prop] = query[prop];
					return  obj;
				}
			}
		};

		console.log(cars)
		console.log(cars.Models.length);

		var easterEgg = hasUserSelectedEasterEgg(self._query);

		// if the user has chosen an easter egg option render single record
		// otherwise begin the filter using the first property in the order collection
		if (easterEgg) {
			var record = cars.Models.filter(Filter.matchSingleRecord, easterEgg);
			Filter.renderSingleRecordThenExit(record);
		} else {
			filterObjectsWithProperty(cars.Models, self._order[(counter.echo())]);
		}

	},

	CarsFactory: function() {
		var collection = [];

		return {
			size: function() {
				return collection.length;
			},
			add: function(item){
				collection.push(item);
			},
			all: function(){
				return collection;
			}
		}
	}

};

( function( Mini ) {

// need a better solution for triggering JS on correct page

if ( $('#dash').length > 0 ){
	Mini.DOMCtrl.init()
	Mini.UILogic.init()
}

	// Write your stuff here. Before doing so, have a look at config.js.

} ( Mini ) );
// Variables

var slot_1			= '#c-bums #roller1 .fake-list';
var slot_2			= '#c-bums #roller2 .fake-list';
var slot_3			= '#c-bums #roller3 .fake-list';
var slot_4			= '#c-bums #roller4 .fake-list';
var slot_5			= '#c-bums #roller5 .fake-list';
var speed_control	= '#c-speed .control.speed .fake-list';

var priceChanged	= false;

// Elements to inject

var svgs = document.querySelectorAll( '.svg' );

// Do the injection

SVGInjector( svgs, {

	pngFallback: 'assets/sprites',

	each: function( svg ) {

		$( svg ).hide().fadeIn( 600 );

	}

} );

// TODO: convert to OO

var $sys = $( '#system ' );

function sysMsg( message ) { $sys.attr( 'data-system-message', message ); }

$( '.control-title' ).click( function( e ) {

	e.preventDefault();
	
	$( this ).toggleClass( 'open' );
	
	// Light

	var $light = $( this ).find( '.light' );
	var color = $( '.car-link' ).css( 'border-color' );

	if( $( this ).hasClass( 'open' ) ) {

		$light.addClass( 'switch-light' );
		$.publish( 'colour-change', color );

	}

	else {

		$light.removeClass( 'switch-light' );
		$light.removeAttr( 'style' );

	}

} );

// Preload images to avoid nasty visual glitches

sysMsg( 'Loading: 0%' );

// Remove 'type' to preload PNGs instead

function preloadImages() {

	$.get( 'preload.php', { type: 'svg' }, function( images ){

		var loaded = 0;
		var $preloader = $( '<div>', { id: 'preloader' } );

		$body.append( $preloader );

		$.map( images, function( el ) {

			// SVGs

			var imgPreload = document.createElementNS( 'http://www.w3.org/2000/svg','image' );
			
			imgPreload.setAttributeNS( 'http://www.w3.org/1999/xlink', 'href', el );
			imgPreload.setAttributeNS( null, 'height', 0 );
			imgPreload.setAttributeNS( null, 'width', 0 );

			// Regular images

			// var imgPreload = new Image();

			// imgPreload.src = el;

			// This is needed because of the SVGs - they need to be injected in to the DOM for the load event to work
			
			$preloader.append( imgPreload );

			imgPreload.addEventListener( 'load', function() {

				loaded++;

				var unit = images.length / 100;
				var percentage = ( loaded / images.length ) * 100;
				var progress;

				progress = Math.floor( percentage );

				// SVGs

				console.debug( imgPreload.href.baseVal + ' preloaded sucessfully (' + progress + '%)' );
				
				// Regular images

				// console.debug( imgPreload.src + ' preloaded sucessfully.' );

				sysMsg( 'Loading: '+ progress + '%' );

				if( progress === 100 ) {

					$sys.toggleClass( 'hidden' );

					$preloader.remove();

				}

			}, false );

		} );

	} );

}

// ################################################## //
//
// FastClick & some global variables
//
// ################################################## //

if( 'addEventListener' in document ) {

	document.addEventListener('DOMContentLoaded', function() { FastClick.attach( document.body ); }, false );

}

// ################################################## //
//
// BG changer
//
// ################################################## //

$.subscribe( 'colour-change', function( e, color) {

	$( '.switch-bg' ).css( {

		'background-color': color,
		'border-color': color

	} );

	$( '.switch-fill path' ).css( {

		'fill': color,

	} );

	$( '.switch-light' ).css( {

		'-webkit-box-shadow': '0 0 5px ' + color + ', 0 0 15px ' + color,
		'-moz-box-shadow': '0 0 5px ' + color + ', 0 0 15px ' + color,
		'-box-shadow': '0 0 5px ' + color + ', 0 0 15px ' + color,
		'background-color': color

	} );

	$( '.switch-color' ).css( 'color', color );

} );

function ui(){

	// ################################################## //
	//
	// Responsive tools
	//
	// ################################################## //

	function scale( el, scale, targetWidth ) {

		var targetWidth 	= targetWidth || $( '#dash' ).width();
		var scale			= scale || false;
		var elWidth			= $( el ).outerWidth();
		var targetScale		= scale ? scale : ( targetWidth / elWidth );

		$( el ).css( {

			'transform': 'scale(' + targetScale + ')',
			// 'transform-origin': '0 0',

		} );

	}

	// ################################################## //
	//
	// Read values from controls
	//
	// ################################################## //

	this.rv = readValues;

	function readValues() {

		var c_v = new Array( getSlotValue( slot_1 ), getSlotValue( slot_2 ), getSlotValue( slot_3 ), getSlotValue( slot_4 ), getSlotValue( slot_5 ) );
		var m_v = mpg_knob._value;
		var l_v = $( luggage_el ).attr( 'class' ).replace( 'dial', '' ).trim();
		var s_v = getSlotValue( speed_control );
		var o_v = getOptions();
		var p_v = getPriceValue( price_control.y )[ 1 ];
		var x_v = getLifestyle();

		var data = {

			seats:		c_v,
			mpg:		m_v,
			luggage:	l_v,
			options:	o_v,
			speed:		s_v,
			price:		( priceChanged ) ? p_v : '999',
			lifestyle:	x_v

		};

		return data;

	}

	function getValues( publish ) {

		var data = readValues();

		$.publish('combobulate-raw', data );

	}

	$( '#get, #start' ).on( 'click', function( e ) { e.preventDefault(); getValues(); } );

	function getOptions() {

		var $inputs = $( '.control.options input:checked' );
		var values = [];

		$inputs.each( function( i, el ) { values.push( $( this ).val() ); } );

		if( values.length <= 0 ) values = 'none';

		return values;

	}

	// ################################################## //
	//
	// Price price
	//
	// ################################################## //

	function getPriceValue( v ) {

		var position	= Math.abs( parseInt( v ) );	
		var level		= Math.abs( ( position / price_control.minY ) * 100 );
		var min			= 190;
		var max			= 300;
		var range		= max - min;
		var value		= parseInt( ( range / 100 ) * level ) + min;

		return [ level, value ];

	}

	var price_el		= document.querySelector( '.control.price .handle' );
	var price_height	= parseInt( $( '.control.price .bounds' ).height() );
	var price_control	= new Draggable( price_el, {

		type: 'y',
		edgeResistance: 1,
		bounds: '.control.price .bounds',
		throwProps: false,
		onDragStart: function() { priceChanged = true; },
		onDrag: function( e ) {

			var level = getPriceValue( this.endY );

			$( '.control.price .switch-bg' ).css( 'height', level[ 0 ] + '%' );

		},
		// liveSnap: true,
		// snap: {
			
		// 	y: function( endValue ) { return Math.round( endValue / 50 ) * 50; }

		// }

	} );

	// ################################################## //
	//
	// Slots
	//
	// ################################################## //

	function resetSlot( slot ) {

		var $list = $( slot ).siblings( '.list' );

		var slotInstance = Draggable.get( slot );

		TweenLite.to( $( slot ).get( 0 ), 0.6, {

			y: 0,
			onComplete: function() { slotInstance.update(); }

		} );

		$list.find( '.item' ).removeClass( 'active' );
		$list.removeClass( 'dragging' ).removeAttr( 'style' );

		slotInstance.update();

	}

	function getSlotState( pos, height, padding ) {

		var currentPosition = Math.abs( pos );
		var activeSlot		= Math.ceil( currentPosition / height );

		return Math.ceil( activeSlot ) + 1;

	}

	function getSlotValue( slot ) {

		var $list			= $( slot ).siblings( '.list' );
		var slotHeight		= 80;
		var draggableY		= Draggable.get( slot ).y;
		var activeSlot		= getSlotState( draggableY, slotHeight, 0 );
		var $slot			= $list.find( '.item' ).eq( activeSlot );
		var value			= $slot.data( 'value' ) || $slot.text();

		return ( value === 'empty' ) ? false : value;

	}

	function initSlot( slot ) {

		var $list = $( slot ).siblings( '.list' );
		var slotHeight	= 80;

		// Make fake list the same height as the real one

		var listHeight = slotHeight * ( $list.find( '.item' ).length - 1 ) ;

		$( slot ).height( listHeight );

		// Initialize Draggable

		var slot_dial	= new Draggable( slot, {

			type: 'y',
			bounds: $( slot ).parent(),
			edgeResistance: 1,
			throwProps: true,
			onDrag: function() {

				var activeSlot		= getSlotState( this.y + 40, slotHeight, 0 );
				var $active			= $list.find( '.item' ).removeClass( 'active' ).eq( activeSlot ).addClass( 'active' );

				$list.addClass( 'dragging' ).css( { 'transform': 'translate3d( 0px, ' + this.y + 'px, 0px )' } );

			},
			onDragEnd: function() {

				$list.removeClass( 'dragging' ).css( { 'transform': 'translate3d( 0px, ' + this.endY + 'px, 0px )' } );

			},
			snap: function( endValue ) {

				var v = Math.round( endValue / slotHeight ) * slotHeight;

				return v;

			}

		} );

	}

	// Init slots

	initSlot( slot_1 );
	initSlot( slot_2 );
	initSlot( slot_3 );
	initSlot( slot_4 );
	initSlot( slot_5 );
	initSlot( speed_control );

	// Randomize slots

	$( '#reset' ).on( 'click', function( e ) {

		e.preventDefault();

		resetSlot( slot_1 );
		resetSlot( slot_2 );
		resetSlot( slot_3 );
		resetSlot( slot_4 );
		resetSlot( slot_5 );

	} );

	// ################################################## //
	//
	// MPG knob
	//
	// ################################################## //

	var mpg_el		= document.querySelector( '.control.mpg .arrow' );
	var mpg_bounds	= 120;
	var mpg_steps	= 13;
	var mpg_min		= 25;
	var mpg_max		= 80;
	var mpg_snap	= 360 / 18;
	var mpg_knob	= new Draggable( mpg_el, {

		type:	'rotation',
		bounds:	{ minRotation: -mpg_bounds, maxRotation: mpg_bounds },
		// liveSnap: true,
		// throwProps: true,
		onDrag:	function() {

			var actual_value	= ( this.rotation + mpg_bounds ) / ( mpg_bounds * 2 );
			var css_name		= parseInt( ( actual_value + ( 1 / ( mpg_steps * 2 ) ) ) * mpg_steps );
			var diff			= mpg_max - mpg_min;
			var v				= parseInt( mpg_min + ( actual_value * diff ) );

			// Update object value

			this._value = v;

			// Update CSS classes

			$( '.control.mpg' ).removeClassExcept( 'control mpg' ).addClass( 'control mpg scale-' + css_name );
			$( '#mpg_value' ).text( v );

		},

		// snap: function( endValue ) { return Math.round( endValue / mpg_snap ) * mpg_snap; }

	} );

	// Move to the initial position

	TweenLite.set( mpg_el, { rotation: -mpg_bounds } );

	// Update rotation & value

	mpg_knob.update();
	mpg_knob._value = mpg_min;

	$( '#mpg_value' ).text( mpg_knob._value );

	// ################################################## //
	//
	// Lifestyle dial
	//
	// ################################################## //

	var lifestyle_el		= document.querySelector( '.control.lifestyle .dial' );
	var lifestyle_bounds	= 5;
	var lifestyle_bounds	= 45;
	var lifestyle_steps		= 4;

	var lifestyle_direction;
	var slick = $( '.items-wrapper' ).slick( {

		arrows: false,
		infinite: true,
		slide: '.item',
		onAfterChange: function() { lifestyle_dial.enable(); }

	} );

	function updateLifestyleDial() {

		// Determine direction

		var direction = ( Math.abs( this.y ) > lifestyle_direction ) ? 'right' : 'left';

		// Temporarily disable dial

		// lifestyle_dial.disable();

		// Move content in the window

		( direction === 'right' ) ? slick.slickPrev() : slick.slickNext();

	};

	var lifestyle_snap		= 360 / 4;
	var lifestyle_dial		= new Draggable( lifestyle_el, {

		type:	'rotation',
		bounds:	{ minRotation: -lifestyle_bounds, maxRotation: lifestyle_bounds },
		throwProps: true,
		// dragResistance: 0.8,
		onDragStart: function() { lifestyle_direction = Math.abs( this.y ); },
		onDragEnd: function() {

			updateLifestyleDial();

		},
		snap: function( endValue ) { return true; }

	} );

	function getLifestyle() { return $( '#c-lifestyle .slick-slide.slick-active' ).attr( 'data-value' ); }


	// ################################################## //
	//
	// Luggage
	//
	// ################################################## //

	function dial_class( r ) {

		var dial_class	= ( ( ( r / luggage_snap ) % luggage_snap ) % 4 );

		if( dial_class === -1 || dial_class === 3 ) { final_class = 'light-packer'; } // light packer
		if( dial_class === -2 || dial_class === 2 ) { final_class = 'lugger'; } // lugger
		if( dial_class === -3 || dial_class === 1 ) { final_class = 'big-loader'; } // big loader
		if( dial_class === 0 ) { final_class = 'minimalist'; } // minimalist
			
		$( luggage_el ).removeClassExcept( 'dial' ).addClass( final_class );

	}

	var luggage_end		= 0;
	var luggage_el		= document.querySelector( '.control.luggage .dial' );
	var luggage_snap	= 360 / 4;
	var luggage_dial	= new Draggable( luggage_el, {

		type:	'rotation',
		throwProps: true,
		onThrowComplete: function() {

			var r = parseInt( this.endRotation );

			dial_class( r );

		},
		onDragStart: function( e ) {

			// Remove all classes

			$( luggage_el ).removeClassExcept( 'dial' );

		},
		onDragEnd: function( e ) {

			var r = parseInt( this.endRotation );

			// Update luggage_end

			luggage_end = r;

		},
		snap: function( endValue ) { return Math.round( endValue / luggage_snap ) * luggage_snap; }

	} );

	$( '.control.luggage .arrows' ).on( 'mousedown mouseup', function( e ) {

		e.preventDefault();

		var className = e.target.id;

		( e.type === 'mousedown' ) ? $( this ).removeClass( 'right left' ).addClass( className ): $( this ).removeClass( 'right left' );

	} );

	$( '#left, #right' ).on( 'click', function( e ) {

		e.preventDefault();

		// Remove all classes

		$( luggage_el ).removeClassExcept( 'dial' );

		var $dial		= $( '.control.luggage .dial' );
		var direction	= e.target.id;
		var nr			= ( direction === 'left' ) ? luggage_end + luggage_snap : luggage_end - luggage_snap;

		// Move to the initial position

		TweenLite.to( luggage_el, 1, { rotation: nr, onComplete: function( v ) { dial_class( nr ); } } );

		// Update rotation & value

		luggage_dial.update();
		luggage_end = nr;

	} );

}

if( Mini.browser.isIE( '>8' ) || ! Mini.browser.isIE() ) preloadImages();

// Dashboard

var ui;

$( document ).ready( function() {

	if( $( '#dash' )[ 0 ] ) {

		ui = new ui();

		// AJAX results page

		// $( '.car-link' ).click( function( e ) {

		// 	e.preventDefault();

		// 	$( '.layout' ).addClass( 'animated fadeOutLeftBig' );

		// 	setTimeout( function() {

		// 		$.get( 'results.php', function( data ) {

		// 			$( '.layout' ).replaceWith( $( data ).find( '.layout' ) );

		// 			Mini.DOMCtrl.panelControl( 'default' );

		// 			$( 'form' ).validate();

		// 			$.publish('colour-change', carColors[ 'Electric Blue' ] );

		// 			$( '#form-submit' ).click( function( e ) {

		// 				e.preventDefault();

		// 				Mini.DOMCtrl.panelControl( 'thanks' );

		// 			} );

		// 		} );

		// 	}, 250 );

		// } );

	}

	// Results page

	else {

		Mini.DOMCtrl.panelControl( 'default' );

		$( 'form' ).validate();

		$.publish('colour-change', carColors[ 'Electric Blue' ] );

		$( '#form-submit' ).click( function( e ) {

			e.preventDefault();

			Mini.DOMCtrl.panelControl( 'thanks' );

		} );

	}

	// $.subscribe('combobulate-raw', function( e, data ) { alert( data.price ); } );

} );
// // Intro animations

// function animate() {

// 	this.bg = function() {

// 		var colors = [

// 			'#f7941d',
// 			'#30b6e8',
// 			'#1164ac',
// 			'#426046',
// 			'#d71d24',
// 			'#d71d24',
// 			'#e4dfce'

// 		];

// 		var i = 0;

// 		var t;

// 		var increment = function() {

// 			$.publish('colour-change', colors[ i ]);

// 			( i < colors.length ) ? i++ : clearInterval( t );

// 		};

// 		t = setInterval( increment, 100 );

// 	};

// 	this.bums = function() {

// 		setSlotValue( _.random( 0, $( slot_1 ).find( '.slot' ).length - 1 ), slot_1 );
// 		setSlotValue( _.random( 0, $( slot_2 ).find( '.slot' ).length - 1 ), slot_2 );
// 		setSlotValue( _.random( 0, $( slot_3 ).find( '.slot' ).length - 1 ), slot_3 );
// 		setSlotValue( _.random( 0, $( slot_4 ).find( '.slot' ).length - 1 ), slot_4 );
// 		setSlotValue( _.random( 0, $( slot_5 ).find( '.slot' ).length - 1 ), slot_5 );

// 	};

// 	this.mpg = function() {

// 		TweenLite.to( mpg_el, 0.6, { rotation: 120 } );
// 		setTimeout( function() { TweenLite.to( mpg_el, 0.6, { rotation: -120 } ); }, 600 );

// 	};

// 	this.options = function() {

// 		$( '.option input' ).each( function( i, el ) {

// 			setTimeout( function() { $( el ).prop( 'checked', true ); }, i * 100 );
			
// 			setTimeout( function() { $( el ).prop( 'checked', false ); }, ( i * 100 ) + 400 );

// 		} );

// 	};

// 	this.price = function() {

// 		TweenLite.to( price_el, 0.6, { y: price_slider.minY } );
// 		setTimeout( function() { TweenLite.to( price_el, 0.6, { y: price_slider.maxY } ); }, 600 );

// 	};

// 	this.lifestyle = function() {

// 		TweenLite.to( lifestyle_el, 0.6, {

// 			rotation: lifestyle_dial.minRotation,
// 			onComplete: function() { updateLifestyleDial(); }

// 		} ); // left

// 		setTimeout( function() { TweenLite.to( lifestyle_el, 0.6, { rotation: 0 } ); }, 600 ); // right

// 	};

// 	this.speed = function() { setSlotValue( $( speed_control ).find( '.slot' ).length - 2, speed_control ); };

// 	this.luggage = function() {

// 		TweenLite.to( luggage_el, 2, { rotation: 360 } );

// 	};

// 	this.bums();
// 	this.mpg();
// 	this.options();
// 	this.price();
// 	this.lifestyle();
// 	this.speed();
// 	this.luggage();
// 	this.bg();

// }

// animate();

// setTimeout( function() {

// 	// $( '#start' ).trigger( 'click' );
// 	Mini.DOMCtrl.panelControl('welcome');

// 	$( 'form' ).validate();

// }, 100 );